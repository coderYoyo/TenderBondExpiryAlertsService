﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Windows.Forms;
using System.Net.Mail;
using TenderTrackingSystem;
using System.Data.SqlClient;
using System.Configuration;
using System.DirectoryServices;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.Runtime.Serialization.Formatters.Binary; 
using System.IO;
using System.Text.RegularExpressions;

namespace TenderBondExpiryAlertsService
{
    public partial class TenderBondExpiryAlertsService : ServiceBase
    {
        public TenderBondExpiryAlertsService()
        {
            InitializeComponent();            
        }

        public static void Main()
        {
            //CultureInfo ci = new CultureInfo("en-US");
            //ci.DateTimeFormat.SetAllDateTimePatterns(new string[] { "dd/MM/yyyy", "MM/dd/yyyy", "MMM-dd-yy" }, 'd');
            //System.Threading.Thread.CurrentThread.CurrentCulture = ci;
            //System.Threading.Thread.CurrentThread.CurrentUICulture = ci;
            TenderBondExpiryAlertsService srv = new TenderBondExpiryAlertsService();
            //if (Environment.UserInteractive)
            //{
                srv.OnStart(null);
            //}
        }

        MemoryStream mStream = null;
        protected override void OnStart(string[] args)
        {
            try
            {
                SqlCommand sqlComm = null;
                using (SqlConnection sqlCn = new SqlConnection(strConn))
                {
                    sqlCn.Open();
                    sqlComm = new SqlCommand("Sp_Validity_ExpireDays", sqlCn);
                    sqlComm.CommandType = CommandType.StoredProcedure;
                    int validityResult = sqlComm.ExecuteNonQuery();
                    sqlComm.Dispose();
                    sqlComm = new SqlCommand("Sp_Tender_BondValidity_ExpireDays", sqlCn);
                    sqlComm.CommandType = CommandType.StoredProcedure;
                    validityResult = sqlComm.ExecuteNonQuery();
                    sqlCn.Close();
                }

                string sqlQueryForAlertNotReceived = "SELECT TenderDatesInfo.org_tender_to_expire,PROJECTS.tender_no, PROJECTS.project_newname_en, " +
                        "  PROJECTS.project_code,Committee.committee_short_name, TenderStatus.Status_Name," +
                        " Department.Department, Committee.committee_id, TenderDatesInfo.proj_id" +
                        " FROM TenderDatesInfo INNER JOIN STAGES INNER JOIN TenderTypes INNER JOIN " +
                        " ContractTypes INNER JOIN FiscalYear INNER JOIN Committee RIGHT OUTER JOIN AFFAIRS INNER JOIN " +
                        " PROJECTS ON AFFAIRS.Affair_id = PROJECTS.Affair_id ON Committee.committee_id = PROJECTS.committee_id ON " +
                        " FiscalYear.FYID = PROJECTS.FYID ON ContractTypes.contract_type_id = PROJECTS.contract_type_id ON " +
                        " TenderTypes.tender_type_id = PROJECTS.tender_type_id INNER JOIN " +
                        " Department ON PROJECTS.department_id = Department.department_id ON STAGES.stage_id = PROJECTS.stage_id ON " +
                        " TenderDatesInfo.proj_id = PROJECTS.proj_id LEFT OUTER JOIN " +
                        " TenderStatus ON PROJECTS.Tender_Status_id = TenderStatus.Tender_Status_id INNER JOIN CONTRACTORS ON PROJECTS.proj_id = CONTRACTORS.proj_id " +
                        " WHERE (TenderStatus.Tender_Status_id not in (1,6,7,8,9,10,15)) AND " +
                        " (TenderDatesInfo.stage_id = 2) AND (TenderDatesInfo.org_tender_to_expire < 20) and (TenderDatesInfo.Alert=0 or TenderDatesInfo.Alert is NULL) " +
                        "AND (CONTRACTORS.cp_contractor_sign IS NULL) and (CONTRACTORS.cp_tender_award is not NULL) ORDER BY TenderDatesInfo.org_tender_to_expire DESC";
                                 
                DAL dalObj = new DAL();
                DataTable dtTenderBondExp = dalObj.GetDataFromDB("TenderBondExpiry", sqlQueryForAlertNotReceived);

                for (Int16 iComtyCounter = 1; iComtyCounter <= 7; iComtyCounter++) // 7 = Number of Committees 
                {
                    DataRow[] drTenderBondExpAlertNotReceived = dtTenderBondExp.Select("committee_id=" + iComtyCounter);

                    if (drTenderBondExpAlertNotReceived.Length != 0)
                    {
                        string sqlQuery = "SELECT DISTINCT USERS.email_address,EmailAlertRecipients.user_id, USERS.user_name, EmailAlertCategory.AlertCategory, EmailAlertRecipients.alert_cat_id, " +
                       " Committee.committee_short_name FROM EmailAlertCategory INNER JOIN EmailAlertRecipients ON EmailAlertCategory.alert_cat_id = EmailAlertRecipients.alert_cat_id INNER JOIN " +
                       " USERS ON EmailAlertRecipients.user_id = USERS.user_id INNER JOIN Committee ON EmailAlertRecipients.committee_id = Committee.committee_id " +
                       " WHERE (EmailAlertRecipients.alert_cat_id = 4) AND (USERS.email_address <> N'') AND (Committee.committee_id =" + iComtyCounter + ")";
                        UserList_ForAlert(sqlQuery);

                        if (userListColl.Count == 0)
                        {
                            UserList_ForAlert("SELECT DISTINCT USERS.email_address from USERS where user_profile_id=1 AND (email_address <> '')");

                            foreach (string strname in userListColl)
                            {

                                MailMessage mailMessage = new MailMessage();

                                mailMessage.From = new MailAddress(ConfigurationManager.AppSettings["adminEmailID"].ToString());
                                mailMessage.To.Add(new MailAddress(strname));
                                mailMessage.Subject = "TCMS Alert: Tender Validity Alert Message";                                
                                
                                mailMessage.Body = "\n" +
                                "This is an automated alert from TCMS." + "\n" +
                                "\n" +
                                "Tender Validity Expiry program is about to sent an alert message to " + drTenderBondExpAlertNotReceived[0].ItemArray[4] + " but there is no identified user to receive the email.\n" +                                     
                                "\n";

                                SmtpClient client = new SmtpClient();
                                client.Host = ConfigurationManager.AppSettings["SmtpHostIP"].ToString();
                                client.Port = Convert.ToInt32(ConfigurationManager.AppSettings["SmtpHostPort"]);
                                client.Send(mailMessage);

                            }                            
                            return;
                        }

                        string sqlQueryForRecordCount = "SELECT count(*)" +  
                       " FROM TenderDatesInfo INNER JOIN STAGES INNER JOIN TenderTypes INNER JOIN " +
                       " ContractTypes INNER JOIN FiscalYear INNER JOIN Committee RIGHT OUTER JOIN AFFAIRS INNER JOIN " +
                       " PROJECTS ON AFFAIRS.Affair_id = PROJECTS.Affair_id ON Committee.committee_id = PROJECTS.committee_id ON " +
                       " FiscalYear.FYID = PROJECTS.FYID ON ContractTypes.contract_type_id = PROJECTS.contract_type_id ON " +
                       " TenderTypes.tender_type_id = PROJECTS.tender_type_id INNER JOIN " +
                       " Department ON PROJECTS.department_id = Department.department_id ON STAGES.stage_id = PROJECTS.stage_id ON " +
                       " TenderDatesInfo.proj_id = PROJECTS.proj_id LEFT OUTER JOIN " +
                       " TenderStatus ON PROJECTS.Tender_Status_id = TenderStatus.Tender_Status_id INNER JOIN CONTRACTORS ON PROJECTS.proj_id = CONTRACTORS.proj_id " +
                       " WHERE (TenderStatus.Tender_Status_id not in (1,6,7,8,9,10,15)) AND " +
                       " (TenderDatesInfo.stage_id = 2) AND (TenderDatesInfo.org_tender_to_expire < 20) AND (CONTRACTORS.cp_contractor_sign IS NULL) AND (CONTRACTORS.cp_tender_award is not NULL) and PROJECTS.committee_id=" + iComtyCounter;

                        DataTable dtTotBondExpPerCommittee = dalObj.GetDataFromDB("TotalTenderBondsExpPerCommittee", sqlQueryForRecordCount);

                        DataTable dtTotalTenderBondExpiry = new DataTable();
                        dtTotalTenderBondExpiry.Columns.Add("ExpiryDays");
                        dtTotalTenderBondExpiry.Columns.Add("TenderNo");
                        dtTotalTenderBondExpiry.Columns.Add("ProjectTitle");
                        dtTotalTenderBondExpiry.Columns.Add("ProjectCode");
                        dtTotalTenderBondExpiry.Columns.Add("TenderCommittee");
                        dtTotalTenderBondExpiry.Columns.Add("TenderStatus");
                        dtTotalTenderBondExpiry.Columns.Add("UserDepartment");
                        dtTotalTenderBondExpiry.Columns.Add("ProjId");
                        dtTotalTenderBondExpiry.AcceptChanges();

                        foreach (DataRow drProj in drTenderBondExpAlertNotReceived)
                        {
                            DataRow dr = dtTotalTenderBondExpiry.NewRow();
                            dr[0] = drProj[0];  //ExpiryDays
                            dr[1] = drProj[1];  //TenderNo
                            dr[2] = drProj[2];  //ProjectTitle
                            dr[3] = drProj[3];  //ProjectCode
                            dr[4] = drProj[4];  //TenderCommittee
                            dr[5] = drProj[5];  //TenderStatus
                            dr[6] = drProj[6];  //UserDepartment       
                            dr[7] = drProj[8];  //ProjId
                            dtTotalTenderBondExpiry.Rows.Add(dr);
                            dtTotalTenderBondExpiry.AcceptChanges();
                        }

                        string sqlQueryForAlertReceived = "SELECT TenderDatesInfo.org_tender_to_expire,PROJECTS.tender_no, PROJECTS.project_newname_en, " +
                        "  PROJECTS.project_code,Committee.committee_short_name, TenderStatus.Status_Name," +
                        " Department.Department, Committee.committee_id, TenderDatesInfo.proj_id" +
                        " FROM TenderDatesInfo INNER JOIN STAGES INNER JOIN TenderTypes INNER JOIN " +
                        " ContractTypes INNER JOIN FiscalYear INNER JOIN Committee RIGHT OUTER JOIN AFFAIRS INNER JOIN " +
                        " PROJECTS ON AFFAIRS.Affair_id = PROJECTS.Affair_id ON Committee.committee_id = PROJECTS.committee_id ON " +
                        " FiscalYear.FYID = PROJECTS.FYID ON ContractTypes.contract_type_id = PROJECTS.contract_type_id ON " +
                        " TenderTypes.tender_type_id = PROJECTS.tender_type_id INNER JOIN " +
                        " Department ON PROJECTS.department_id = Department.department_id ON STAGES.stage_id = PROJECTS.stage_id ON " +
                        " TenderDatesInfo.proj_id = PROJECTS.proj_id LEFT OUTER JOIN " +
                        " TenderStatus ON PROJECTS.Tender_Status_id = TenderStatus.Tender_Status_id INNER JOIN CONTRACTORS ON PROJECTS.proj_id = CONTRACTORS.proj_id " +
                        " WHERE (TenderStatus.Tender_Status_id not in (1,6,7,8,9,10,15)) AND " +
                        " (TenderDatesInfo.stage_id = 2) AND (TenderDatesInfo.org_tender_to_expire < 20) and TenderDatesInfo.Alert=1 AND PROJECTS.committee_id =" + iComtyCounter +
                        " AND (CONTRACTORS.cp_contractor_sign IS NULL) AND (CONTRACTORS.cp_tender_award is not NULL) ORDER BY TenderDatesInfo.org_tender_to_expire DESC";

                        DataTable dtTenderBondsExpForAlertsReceived = dalObj.GetDataFromDB("TenderBondsExpForAlertsReceived", sqlQueryForAlertReceived);

                        foreach (DataRow drForAlertsReceived in dtTenderBondsExpForAlertsReceived.Rows)
                        {
                            DataRow dr = dtTotalTenderBondExpiry.NewRow();
                            dr[0] = drForAlertsReceived[0];  //ExpiryDays
                            dr[1] = drForAlertsReceived[1];  //TenderNo
                            dr[2] = drForAlertsReceived[2];  //ProjectTitle
                            dr[3] = drForAlertsReceived[3];  //ProjectCode
                            dr[4] = drForAlertsReceived[4];  //TenderCommittee
                            dr[5] = drForAlertsReceived[5];  //TenderStatus
                            dr[6] = drForAlertsReceived[6];  //UserDepartment       
                            dr[7] = drForAlertsReceived[8];  //ProjId
                            dtTotalTenderBondExpiry.Rows.Add(dr);
                            dtTotalTenderBondExpiry.AcceptChanges();
                        }

                        StringBuilder strBuild = null;
                        mStream = new MemoryStream();
                        try
                        {
                            byte[] newPdf = null;
                            iTextSharp.text.Font headerText = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.TIMES_ROMAN, 12f);
                            iTextSharp.text.Font plainText = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.TIMES_ROMAN, 8f);

                            using (var pdfMemStream = new MemoryStream())
                            {
                                var doc = new Document(iTextSharp.text.PageSize.A4);
                                using (PdfWriter writer = PdfWriter.GetInstance(doc, pdfMemStream))
                                {
                                    doc.AddAuthor("PWA-ASHGHAL");
                                    doc.AddCreator("TCMS-APP");
                                    //doc.AddTitle(sNrOferty);
                                    PageEventHelper pageEventHelper = new PageEventHelper();
                                    writer.PageEvent = pageEventHelper;
                                    doc.Open();

                                    PdfPTable pdfTable = new PdfPTable(7);
                                    pdfTable.TotalWidth = 555f;
                                    pdfTable.LockedWidth = true;
                                    float[] widths = new float[] { 9f, 23f, 27f, 16f, 10f, 13f, 19f };
                                    //float[] widths = new float[] { 8f, 22f, 27f, 16f, 10f, 13f, 17f,10f,10f };                                    

                                    Chunk ch = new Chunk("List of Projects where Tender Validity Expiration is Less than 20 days", headerText);
                                    Chunk boldCh4 = new Chunk("                                            Project Count =" + dtTotBondExpPerCommittee.Rows[0][0], plainText);
                                    Phrase p1 = new Phrase(ch);
                                    p1.Add(boldCh4);
                                    Paragraph pg4 = new Paragraph();
                                    pg4.Add(p1);
                                    pg4.SpacingAfter = 10f;
                                    doc.Add(pg4);

                                    pdfTable.SetWidths(widths);
                                    pdfTable = createTable(dtTotalTenderBondExpiry, pdfTable);
                                    doc.Add(pdfTable);
                                    doc.Close();
                                    newPdf = pdfMemStream.GetBuffer();
                                }
                            }
                            
                            strBuild = new StringBuilder();
                            mStream.Write(newPdf, 0, newPdf.Length);                             
                            mStream.Position = 0;                            

                            //string DisplayName = ""; string Email = ""; string Department = ""; string Title = "";
                            
                            // AlertOnNewTenderNo(tenderNo, _projID.ToString(), "New Project");

                            //string fromUser = string.Empty;                             
                            //fromUser = "ebsd_vpuchnanda";                            
                             
                            //if (GetUserInformation4rmActiveDirectory(fromUser, "ashghal.gov.qa", ref user_DisplayName, ref user_Email, ref  user_Department, ref user_Title) == true)
                            //{
                                foreach (string strname in userListColl)
                                {                                    
                                        MailMessage mailMessage = new MailMessage();                                    

                                        mailMessage.From = new MailAddress(ConfigurationManager.AppSettings["adminEmailID"].ToString());
                                        mailMessage.To.Add(new MailAddress(strname));
                                        mailMessage.Subject = "TCMS Alert: Updated list of " + dtTotalTenderBondExpiry.Rows[0][4] + " Projects where Tender Validity Will Expire in less than 20 Day";                                         
                                        System.Net.Mime.ContentType ct = new System.Net.Mime.ContentType(System.Net.Mime.MediaTypeNames.Application.Pdf);
                                        Attachment attach = new Attachment(mStream,ct);//strBuild.ToString()); // Regex.Replace(strBuild.ToString(), @"\\", @"/")                                   
                                        attach.ContentDisposition.FileName = "Tender Validity Expiration Per Committee.pdf";
                                        mailMessage.Attachments.Add(attach);

                                        if (drTenderBondExpAlertNotReceived.Length == 1)
                                        {
                                            mailMessage.Body = "\n" +
                                            "This is an automated alert from TCMS." + "\n" +
                                            "\n" +
                                            drTenderBondExpAlertNotReceived.Length + " Project is added in the list of " + dtTotalTenderBondExpiry.Rows[0][4] + " where Tender Validity will expire in less than 20 days. Attached is the updated list for your \n" +
                                            "information. Total count of project in the updated list is " + dtTotBondExpPerCommittee.Rows[0][0] + ".\n" +
                                            "\n";
                                        }
                                        else
                                        {
                                            mailMessage.Body = "\n" +
                                           "This is an automated alert from TCMS." + "\n" +
                                           "\n" +
                                           drTenderBondExpAlertNotReceived.Length + " Projects are added in the list of " + dtTotalTenderBondExpiry.Rows[0][4] + " where Tender Validity will expire in less than 20 days. Attached is the updated list for your \n" +
                                           "information. Total count of project in the updated list is " + dtTotBondExpPerCommittee.Rows[0][0] + ".\n" +
                                           "\n";
                                        }

                                        //mailMessage.Body = "<html><body><i style='font-family:Calibri; font-size:15'>Dear Sir/Madam,</i><br/><br/><i style='font-family:Calibri; font-size:15'>This is an automated alert from Tender & Contract Management System.</i><br/><br/><i style='font-family:Calibri;font-size:15'>" +
                                        //"Please be noted that</i><i style='color:Maroon;font-family:Calibri; font-size:15'> New Tender No. " + strTenderNo + "</i><i style='font-family:Calibri; font-size:15'> has created and the details are as follows:-</i><br /><br />" +
                                        //"<table style='width:80%' border='1'><tr><td align='center' colspan='2' style='background-color:Maroon;color:White;font-family:Calibri;font-size:18;font-weight:bold'>TENDER NO: " + strTenderNo + "</td>" +
                                        //"</tr><tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Project Code</i></td><td style='font-family:Calibri;font-size:15'>" + _prjCode + "</td></tr>" +
                                        //"<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Project Title</i></td><td style='font-family:Calibri;font-size:15'>" + proj_Title + "</td></tr>" +
                                        //"<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Type of Tender</i></td><td style='font-family:Calibri;font-size:15'>" + _tndrTypeName + "</td></tr>" +
                                        //"<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Tender Committee</i></td><td style='font-family:Calibri;font-size:15'>" + _cmtName + "</td></tr>" +
                                        //"<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Financial Year</i></td><td style='font-family:Calibri;font-size:15'>" + _fiscalYear + "</td></tr>" +       //+ "(" + _AffairsName + ")
                                        //"<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>User Dept.</i></td><td style='font-family:Calibri;font-size:15'>" + _userDept + " / " + _AffairsName + " </td></tr>" +
                                        //"<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Date of Creation</i></td><td style='font-family:Calibri;font-size:15'>" + System.DateTime.Now + "</td></tr>" +
                                        //"</table><br/><br/><div style='font-family:Calibri; font-size:15'>Best Regards,<br/>TCMS Team</div></body></html>";
                                       
                                        SmtpClient client = new SmtpClient();
                                        client.Host = ConfigurationManager.AppSettings["SmtpHostIP"].ToString();
                                        client.Port = Convert.ToInt32(ConfigurationManager.AppSettings["SmtpHostPort"]);
                                        client.Send(mailMessage);
                                        mStream.Position = 0;                                     

                                }

                                 
                                Int16 tndrBondExpiryWithoutAlertCounter = 0;
                                using (SqlConnection sqlCn = new SqlConnection(strConn))
                                {
                                    sqlCn.Open();
                                    while (tndrBondExpiryWithoutAlertCounter < dtTotalTenderBondExpiry.Rows.Count)
                                    {
                                        string sqlUpdateAlertStatusQuery = "Update TenderDatesInfo set TenderDatesInfo.Alert = 1" +
                                        " where  TenderDatesInfo.proj_id =" + dtTotalTenderBondExpiry.Rows[tndrBondExpiryWithoutAlertCounter][7];
                                        dalObj.ExecuteNonQuery(sqlUpdateAlertStatusQuery,sqlCn);
                                        tndrBondExpiryWithoutAlertCounter++;
                                    
                                    }
                                    sqlCn.Close();
                                }

                                WriteToLog(DateTime.Now + "::" + "Successfully send the email notification to Tender Committee and updated the alert status");                                
                            //}
                        }
                        catch (Exception ex)
                        {
                            WriteToLog(DateTime.Now + "::" + "Error occurred while sending the email notification to a member of Tender Committee" + "::" + ex.Message);
                        }
                    }
                }
            }
            catch (DocumentException dex)
            {
                WriteToLog(DateTime.Now + "::" + "Error occurred while creating the pdf file" + "::" + dex.Message);
            }
            catch (IOException ioex)
            {
                //Handle IO exception //"Exception occurred while creating the pdf file"
                WriteToLog(DateTime.Now + "::" + "Error occurred while creating the pdf file" + "::" + ioex.Message);
            }
            catch (Exception ex)
            {
                WriteToLog(DateTime.Now + "::" + "Error occurred while creating the pdf file" + "::" + ex.Message);
            }
        }

        private PdfPTable createTable(DataTable dtTenderBondExpiry, PdfPTable pdfTab)
        {
                iTextSharp.text.Font plainText = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.TIMES_ROMAN, 8f);
                iTextSharp.text.Font boldText = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.TIMES_ROMAN, 9f, iTextSharp.text.Font.BOLD, iTextSharp.text.BaseColor.BLACK);                

                // storing header part in pdf file
                for (int i = 0; i < 7; i++)
                {
                    PdfPCell tabCell = new PdfPCell();
                    tabCell.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
                    tabCell.BorderWidth = 1f;
                    Paragraph snPg = null;

                    boldText.Color = new BaseColor(255, 255, 255);
                    if (i == 0)
                        snPg = new Paragraph("Days To Expire", boldText);
                    if (i == 1)
                        snPg = new Paragraph("Tender No.", boldText);
                    if (i == 2)
                        snPg = new Paragraph("Project Title", boldText);
                    if (i == 3)
                        snPg = new Paragraph("Project Code", boldText);
                    if (i == 4)
                        snPg = new Paragraph("Committee", boldText);
                    if (i == 5)
                        snPg = new Paragraph("Tender Status", boldText);
                    if (i == 6)
                        snPg = new Paragraph("Department", boldText);

                    snPg.Alignment = iTextSharp.text.pdf.PdfContentByte.ALIGN_CENTER;
                    tabCell.BackgroundColor = new BaseColor(153, 0, 76);
                    tabCell.AddElement(snPg);
                    pdfTab.AddCell(tabCell);
                }
                pdfTab.HeaderRows = 1;

                // storing Each row and column value to pdf file
                for (int i = 0; i < dtTenderBondExpiry.Rows.Count; i++)
                {
                    for (int j = 0; j < 7; j++)
                    {
                        PdfPCell tabCell = new PdfPCell();
                        tabCell.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
                        Paragraph snPg = null;
                        snPg = new Paragraph(dtTenderBondExpiry.Rows[i][j].ToString(), plainText);
                        snPg.Alignment = iTextSharp.text.pdf.PdfContentByte.ALIGN_CENTER;
                        tabCell.AddElement(snPg);
                        pdfTab.AddCell(tabCell);
                    }

                }

                pdfTab.SpacingBefore = 10f;
                pdfTab.HorizontalAlignment = iTextSharp.text.pdf.PdfContentByte.ALIGN_CENTER;
                return pdfTab;
        }

        string strConn = ConfigurationManager.AppSettings["TCMSConnString"].ToString();       
        IList<string> userListColl = new List<string>();
        private void UserList_ForAlert(string sqlQuery)
        {
            userListColl.Clear();
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(strConn))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();                      

                        cmd.Connection = sqlConn;
                        cmd.CommandText = sqlQuery;
                        using (SqlDataReader dr = cmd.ExecuteReader())
                        {
                            while (dr.Read())
                            {
                                string strData = dr[0].ToString();
                                if (!userListColl.Contains(strData))
                                    userListColl.Add(strData);
                            }
                            dr.Close();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                WriteToLog(DateTime.Now + "::" + "Error occurred while creating Tender Bond Expiry table" + "::" + ex.Message);                                 
            }
        }

        public Boolean GetUserInformation4rmActiveDirectory(string userId, string Domain, ref string DisplayName, ref string Email, ref string Department, ref string Title)
        {
            Boolean chkUserExist = false;
            try
            {
                string filter = string.Format("(&(ObjectClass={0})(sAMAccountName={1}))", "person", userId);

                DirectoryEntry activeDirectoryaddress = new DirectoryEntry("LDAP://" + Domain, null, null, AuthenticationTypes.Secure);
                DirectorySearcher searcher = new DirectorySearcher(activeDirectoryaddress);
                searcher.SearchScope = SearchScope.Subtree;

                searcher.Filter = filter;
                SearchResult result = searcher.FindOne();
                DirectoryEntry directoryEntry = result.GetDirectoryEntry();

                DisplayName = directoryEntry.Properties["displayName"][0].ToString();
                Email = directoryEntry.Properties["mail"][0].ToString();
                Department = directoryEntry.Properties["department"][0].ToString();
                Title = directoryEntry.Properties["title"][0].ToString();

                if (Email != null)
                {
                    chkUserExist = true;
                }
            }
            catch (Exception ex)
            {                
                WriteToLog(DateTime.Now + "::" + "Sorry unable to get your mail id from outlook" + "::" + ex.Message);                
            }

            return chkUserExist;
        }
        protected override void OnStop()
        {
        }

        void WriteToLog(string errMsg)
        {
            FileStream fileStreamObj = null;
            StreamWriter streamWriterObj = null;
            string strFileName = ConfigurationManager.AppSettings["LogFile"];
            bool boolFlag = File.Exists(strFileName);

            if (boolFlag)
                fileStreamObj = new FileStream(strFileName, FileMode.Append, FileAccess.Write);
            else
                fileStreamObj = new FileStream(strFileName, FileMode.OpenOrCreate, FileAccess.Write);

            streamWriterObj = new StreamWriter(fileStreamObj);
            //if (lineCount != 1)
            //{
            //    streamWriterObj.WriteLine(errMsg.Split('.')[0]);
            //    streamWriterObj.WriteLine(errMsg.Split('.')[1]);
            //    streamWriterObj.WriteLine(streamWriterObj.NewLine);
            //    streamWriterObj.Flush();
            //}
            //else
            //{
            streamWriterObj.WriteLine(errMsg);
            streamWriterObj.WriteLine(streamWriterObj.NewLine);
            //streamWriterObj.Flush();
            //}
            streamWriterObj.Close(); 
            //fileStreamObj.Flush();
            fileStreamObj.Close();

        }

        public class PageEventHelper : PdfPageEventHelper
        {
            PdfTemplate template;
            protected BaseFont bf;

            public override void OnOpenDocument(PdfWriter writer, Document document)
            {
                template = writer.DirectContent.CreateTemplate(100, 100);
                template.BoundingBox = new iTextSharp.text.Rectangle(-20, -20, 100, 100);
                bf = BaseFont.CreateFont(BaseFont.TIMES_ROMAN, BaseFont.CP1252, BaseFont.NOT_EMBEDDED);
            }

            public override void OnEndPage(PdfWriter writer, Document document)
            {
                //base.OnEndPage(writer, document);
                PdfContentByte cb = writer.DirectContent;

                int pageN = writer.PageNumber;
                String text = "Page " + pageN + " of ";
                float len = bf.GetWidthPoint(text, 9);

                iTextSharp.text.Rectangle pageSize = document.PageSize;

                //cb.SetRGBColorFill(100, 100, 100);

                cb.BeginText();
                cb.SetFontAndSize(bf, 9);
                cb.SetTextMatrix(pageSize.GetLeft(70), pageSize.GetBottom(30));
                cb.ShowText(System.DateTime.Now.ToLongDateString());
                cb.EndText();

                //cb.AddTemplate(template, pageSize.GetLeft(70) + len, pageSize.GetBottom(30));

                //cb.BeginText();
                //cb.SetFontAndSize(bf, 9);
                //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT,
                //    "",
                //    pageSize.GetLeft(70),
                //    pageSize.GetBottom(30), 0);
                //cb.EndText();

                cb.BeginText();
                cb.SetFontAndSize(bf, 9);
                cb.SetTextMatrix(pageSize.GetRight(70), pageSize.GetBottom(30));
                cb.ShowText(text);
                cb.EndText();

                cb.AddTemplate(template, pageSize.GetRight(70) + len, pageSize.GetBottom(30));

                //cb.BeginText();
                //cb.SetFontAndSize(bf, 9);
                //cb.ShowTextAligned(PdfContentByte.ALIGN_RIGHT,
                //    "",
                //    pageSize.GetRight(70),
                //    pageSize.GetBottom(30), 0);
                //cb.EndText();
            }

            public override void OnCloseDocument(PdfWriter writer, Document document)
            {
                //base.OnCloseDocument(writer, document);

                template.BeginText();
                template.SetFontAndSize(bf, 9);
                template.SetTextMatrix(0, 0);
                template.ShowText("" + (writer.PageNumber - 1));
                template.EndText();
            }

        }
    }
}
