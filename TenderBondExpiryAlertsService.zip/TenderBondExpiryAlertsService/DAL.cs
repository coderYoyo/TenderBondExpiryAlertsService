﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration; 

namespace TenderTrackingSystem
{
    class DAL
    {       

        SqlDataAdapter da = null;                             
        string strCon = ConfigurationSettings.AppSettings["TCMSConnString"].ToString();       

        public DataTable GetDataFromDB(string dataTabName, string sqlQuery)
        {
            DataTable table = null;
            try
            {
                table = new DataTable(dataTabName);
                SqlConnection conn = new SqlConnection(strCon);
                conn.Open();
                da = new SqlDataAdapter(@sqlQuery, conn);                 
                da.Fill(table);
            }
            catch (Exception ex)
            {
                return null;
            }
            return table;
        }

        public void ExecuteNonQuery(string sqlString,SqlConnection sqlConn)
        {
            SqlCommand sqlCommand = new SqlCommand(sqlString, sqlConn);
            sqlCommand.ExecuteNonQuery();
            sqlCommand.Dispose();             
        }

    } 
}
