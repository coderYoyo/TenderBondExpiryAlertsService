﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Windows.Forms;
using System.Net.Mail;
using TenderTrackingSystem;
using System.Data.SqlClient;
using System.Configuration;
using System.DirectoryServices;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.Runtime.Serialization.Formatters.Binary; 
using System.IO;
using System.Text.RegularExpressions;
using System.Net;
using System.Security.Cryptography.X509Certificates;
using System.Net.Security;

namespace TenderBondExpiryAlertsService
{
    public partial class TenderBondExpiryAlertsService : ServiceBase
    {
        public TenderBondExpiryAlertsService()
        {
            InitializeComponent();            
        }

        public static void Main()
        {
            //CultureInfo ci = new CultureInfo("en-US");
            //ci.DateTimeFormat.SetAllDateTimePatterns(new string[] { "dd/MM/yyyy", "MM/dd/yyyy", "MMM-dd-yy" }, 'd');
            //System.Threading.Thread.CurrentThread.CurrentCulture = ci;
            //System.Threading.Thread.CurrentThread.CurrentUICulture = ci;
            TenderBondExpiryAlertsService srv = new TenderBondExpiryAlertsService();
            //if (Environment.UserInteractive)
            //{
                srv.OnStart(null);
            //}
        }

        MemoryStream mStream = null;
        byte[] ashLogoImage = null;
        protected override void OnStart(string[] args)
        {
            try
            {
                try
                {
                    // Test Email for checking the SMTP Server is up and running Added By Varun on 31st Jan 2016
                    MailMessage mailMessage = new MailMessage();

                    mailMessage.From = new MailAddress(ConfigurationManager.AppSettings["From"].ToString());
                    mailMessage.To.Add(new MailAddress(ConfigurationManager.AppSettings["To"].ToString()));
                    mailMessage.Subject = "Test TCMS Alert: Tender Bond Expiry Alerts";
                    mailMessage.IsBodyHtml = true;


                    mailMessage.Body = "<html><body><i style='font-family:Calibri; font-size:15'>Dear Sir/Madam,</i><br/><br/><i style='font-family:Calibri; font-size:15'>This is an automated alert from Tender & Contract Management System.</i><br/><br/><i style='font-family:Calibri;font-size:15'>" +
                    "Please be noted that</i><i style='color:Maroon;font-family:Calibri; font-size:15'>sending the email notification for Tender Bond Expiry Alerts</i><br /><br />" +
                    "<table style='width:80%' border='1'>" +
                    "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Date of Creation</i></td><td style='font-family:Calibri;font-size:15'>" + System.DateTime.Now + "</td></tr>" +
                    "</table><br/><br/></body></html>";

                    //mailMessage.Body = "This is an automated alert from TCMS." + "\n" + "\n" + "Project Code     : " + _prjCode + "\n" + "Project Title    : " + proj_Title + "\n" +   "Type of Tender   : " + _tndrTypeName + " " +
                    // "\n"  + "Tender Committee : " + _cmtName + " " +
                    // "\n" +  "User Department  : " + _userDept + " " +
                    // "\n" +  "Date Created     : " + System.DateTime.Now.ToString() + " " +
                    //" \n" +  "\n" + "Tender No. " + strTenderNo + " was assigned to above project.";

                    SmtpClient client = new SmtpClient();
                    client.EnableSsl = true;
                    ServicePointManager.ServerCertificateValidationCallback = delegate(object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };
                    client.Credentials = new System.Net.NetworkCredential(@"tcms", ConfigurationManager.AppSettings["emailPass"].ToString());                    
                    client.Host = ConfigurationManager.AppSettings["SmtpHostIP"].ToString();
                    client.Port = Convert.ToInt32(ConfigurationManager.AppSettings["SmtpHostPort"]);
                    client.Send(mailMessage);


                }
                catch (Exception ex)
                {
                    WriteToLog(DateTime.Now + "::" + "Exception occurred while sending the email notification for Tender Bond Expiry Alerts" + "::" + ex.Message);                     
                    return;
                }

                SqlCommand sqlComm = null;                
                using (SqlConnection sqlCn = new SqlConnection(strConn))
                {
                    sqlCn.Open();
                    sqlComm = new SqlCommand("Sp_Validity_ExpireDays", sqlCn);
                    sqlComm.CommandType = CommandType.StoredProcedure;
                    int validityResult = sqlComm.ExecuteNonQuery();
                    sqlComm.Dispose();
                    sqlComm = new SqlCommand("Sp_Tender_BondValidity_ExpireDays", sqlCn);
                    sqlComm.CommandType = CommandType.StoredProcedure;
                    validityResult = sqlComm.ExecuteNonQuery();

                    String sqlQuery = "Select LogoImage from Logo where LogoId = 1";                    
                    SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlCn);
                    SqlDataReader sqlDtReader = sqlCom.ExecuteReader();
                    if (sqlDtReader.Read())
                    {
                        ashLogoImage = (byte[])sqlDtReader[0];                        
                    }
                    sqlDtReader.Close();
                    sqlCn.Close();
                }

                // Queries for sending emails on Tender Bond Validity Expiration when Contract Info is present (For Non Direct Order Tender's)

                string sqlQueryForAlertNotReceived = "SELECT TenderDatesInfo.org_tenderbond_validity, TenderDatesInfo.tenderbond_validity_ext1,TenderDatesInfo.tenderbond_validity_ext2,PROJECTS.tender_no, PROJECTS.project_newname_en, " +
                "  PROJECTS.project_code,Committee.committee_short_name, TenderStatus.Status_Name," +
                " Department.Department, Committee.committee_id, TenderDatesInfo.proj_id " +
                " FROM TenderDatesInfo INNER JOIN STAGES INNER JOIN TenderTypes INNER JOIN " +
                " ContractTypes INNER JOIN FiscalYear INNER JOIN Committee RIGHT OUTER JOIN AFFAIRS INNER JOIN " +
                " PROJECTS ON AFFAIRS.Affair_id = PROJECTS.Affair_id ON Committee.committee_id = PROJECTS.committee_id ON " +
                " FiscalYear.FYID = PROJECTS.FYID ON ContractTypes.contract_type_id = PROJECTS.contract_type_id ON " +
                " TenderTypes.tender_type_id = PROJECTS.tender_type_id INNER JOIN " +
                " Department ON PROJECTS.department_id = Department.department_id ON STAGES.stage_id = PROJECTS.stage_id ON " +
                " TenderDatesInfo.proj_id = PROJECTS.proj_id INNER JOIN " +
                " TenderStatus ON PROJECTS.Tender_Status_id = TenderStatus.Tender_Status_id INNER JOIN CONTRACTORS ON PROJECTS.proj_id = CONTRACTORS.proj_id " +
                " WHERE (TenderStatus.Tender_Status_id not in (1, 7, 8, 9, 10, 14, 15, 16)) AND " +
                " (TenderDatesInfo.stage_id = 2) AND (TenderDatesInfo.org_tenderbond_to_expire <=7) and (Year(TenderDatesInfo.org_tenderbond_validity)=YEAR(GETDATE()) OR YEAR(TenderDatesInfo.org_tenderbond_validity) = YEAR(GETDATE()) - 1) and (TenderDatesInfo.Alert=0 or TenderDatesInfo.Alert is NULL) " +
                "AND (CONTRACTORS.cp_contractor_sign IS NULL OR CONTRACTORS.cp_sent_dep_sign IS NULL) AND (TenderDatesInfo.org_tenderbond_validity IS NOT NULL) AND (PROJECTS.tender_no NOT LIKE '%DO%') ORDER BY TenderDatesInfo.org_tenderbond_validity DESC";

                string sqlQueryForRecordCount = "SELECT count(*)" +
                " FROM TenderDatesInfo INNER JOIN STAGES INNER JOIN TenderTypes INNER JOIN " +
                " ContractTypes INNER JOIN FiscalYear INNER JOIN Committee RIGHT OUTER JOIN AFFAIRS INNER JOIN " +
                " PROJECTS ON AFFAIRS.Affair_id = PROJECTS.Affair_id ON Committee.committee_id = PROJECTS.committee_id ON " +
                " FiscalYear.FYID = PROJECTS.FYID ON ContractTypes.contract_type_id = PROJECTS.contract_type_id ON " +
                " TenderTypes.tender_type_id = PROJECTS.tender_type_id INNER JOIN " +
                " Department ON PROJECTS.department_id = Department.department_id ON STAGES.stage_id = PROJECTS.stage_id ON " +
                " TenderDatesInfo.proj_id = PROJECTS.proj_id INNER JOIN " +
                " TenderStatus ON PROJECTS.Tender_Status_id = TenderStatus.Tender_Status_id INNER JOIN CONTRACTORS ON PROJECTS.proj_id = CONTRACTORS.proj_id " +
                " WHERE (TenderStatus.Tender_Status_id not in (1, 7, 8, 9, 10, 14, 15, 16)) AND " +
                " (TenderDatesInfo.stage_id = 2) AND (TenderDatesInfo.org_tenderbond_to_expire <=7) and (Year(TenderDatesInfo.org_tenderbond_validity)=YEAR(GETDATE()) OR YEAR(TenderDatesInfo.org_tenderbond_validity) = YEAR(GETDATE()) - 1)" +
                " AND (TenderDatesInfo.org_tenderbond_validity IS NOT NULL) AND (PROJECTS.tender_no NOT LIKE '%DO%') and PROJECTS.committee_id=";


                string sqlQueryForAlertReceived = "SELECT TenderDatesInfo.org_tenderbond_validity, TenderDatesInfo.tenderbond_validity_ext1,TenderDatesInfo.tenderbond_validity_ext2,PROJECTS.tender_no, PROJECTS.project_newname_en, " +
                "  PROJECTS.project_code,Committee.committee_short_name, TenderStatus.Status_Name," +
                " Department.Department, Committee.committee_id, TenderDatesInfo.proj_id" +
                " FROM TenderDatesInfo INNER JOIN STAGES INNER JOIN TenderTypes INNER JOIN " +
                " ContractTypes INNER JOIN FiscalYear INNER JOIN Committee INNER JOIN AFFAIRS INNER JOIN " +
                " PROJECTS ON AFFAIRS.Affair_id = PROJECTS.Affair_id ON Committee.committee_id = PROJECTS.committee_id ON " +
                " FiscalYear.FYID = PROJECTS.FYID ON ContractTypes.contract_type_id = PROJECTS.contract_type_id ON " +
                " TenderTypes.tender_type_id = PROJECTS.tender_type_id INNER JOIN " +
                " Department ON PROJECTS.department_id = Department.department_id ON STAGES.stage_id = PROJECTS.stage_id ON " +
                " TenderDatesInfo.proj_id = PROJECTS.proj_id INNER JOIN " +
                " TenderStatus ON PROJECTS.Tender_Status_id = TenderStatus.Tender_Status_id INNER JOIN CONTRACTORS ON PROJECTS.proj_id = CONTRACTORS.proj_id " +
                " WHERE (TenderStatus.Tender_Status_id not in (1, 7, 8, 9, 10, 14, 15, 16)) AND " +
                " (TenderDatesInfo.stage_id = 2) AND (TenderDatesInfo.org_tenderbond_to_expire <=7) and (Year(TenderDatesInfo.org_tenderbond_validity)=YEAR(GETDATE()) OR YEAR(TenderDatesInfo.org_tenderbond_validity) = YEAR(GETDATE()) - 1) " +
                "AND TenderDatesInfo.Alert=1 AND (TenderDatesInfo.org_tenderbond_validity IS NOT NULL) AND (PROJECTS.tender_no NOT LIKE '%DO%') AND PROJECTS.committee_id =";

                // Method for sending emails on Tender Bond Validity Expiration  
                SendEmailOnTenderBondValidityExpiry(sqlQueryForAlertNotReceived,sqlQueryForRecordCount,sqlQueryForAlertReceived);

                // Queries for sending emails on Tender Bond Validity Expiration when Contract Info is not present (For Direct Order Tender's)

                sqlQueryForAlertNotReceived = "SELECT TenderDatesInfo.org_tenderbond_validity, TenderDatesInfo.tenderbond_validity_ext1,TenderDatesInfo.tenderbond_validity_ext2,PROJECTS.tender_no, PROJECTS.project_newname_en, " +
                "  PROJECTS.project_code,Committee.committee_short_name, TenderStatus.Status_Name," +
                " Department.Department, Committee.committee_id, TenderDatesInfo.proj_id " +
                " FROM TenderDatesInfo INNER JOIN STAGES INNER JOIN TenderTypes INNER JOIN " +
                " ContractTypes INNER JOIN FiscalYear INNER JOIN Committee RIGHT OUTER JOIN AFFAIRS INNER JOIN " +
                " PROJECTS ON AFFAIRS.Affair_id = PROJECTS.Affair_id ON Committee.committee_id = PROJECTS.committee_id ON " +
                " FiscalYear.FYID = PROJECTS.FYID ON ContractTypes.contract_type_id = PROJECTS.contract_type_id ON " +
                " TenderTypes.tender_type_id = PROJECTS.tender_type_id INNER JOIN " +
                " Department ON PROJECTS.department_id = Department.department_id ON STAGES.stage_id = PROJECTS.stage_id ON " +
                " TenderDatesInfo.proj_id = PROJECTS.proj_id INNER JOIN " +
                " TenderStatus ON PROJECTS.Tender_Status_id = TenderStatus.Tender_Status_id " +
                " WHERE (TenderStatus.Tender_Status_id not in (1, 6, 7, 8, 9, 10, 14, 15, 16)) AND " +
                " (TenderDatesInfo.stage_id = 2) AND (TenderDatesInfo.org_tenderbond_to_expire <=7) and (Year(TenderDatesInfo.org_tenderbond_validity)=YEAR(GETDATE()) OR YEAR(TenderDatesInfo.org_tenderbond_validity) = YEAR(GETDATE()) - 1) and (TenderDatesInfo.Alert=0 or TenderDatesInfo.Alert is NULL) " +
                "AND (TenderDatesInfo.org_tenderbond_validity IS NOT NULL) AND (PROJECTS.tender_no LIKE '%DO%') ORDER BY TenderDatesInfo.org_tenderbond_validity DESC";

                sqlQueryForRecordCount = "SELECT count(*)" +
                " FROM TenderDatesInfo INNER JOIN STAGES INNER JOIN TenderTypes INNER JOIN " +
                " ContractTypes INNER JOIN FiscalYear INNER JOIN Committee RIGHT OUTER JOIN AFFAIRS INNER JOIN " +
                " PROJECTS ON AFFAIRS.Affair_id = PROJECTS.Affair_id ON Committee.committee_id = PROJECTS.committee_id ON " +
                " FiscalYear.FYID = PROJECTS.FYID ON ContractTypes.contract_type_id = PROJECTS.contract_type_id ON " +
                " TenderTypes.tender_type_id = PROJECTS.tender_type_id INNER JOIN " +
                " Department ON PROJECTS.department_id = Department.department_id ON STAGES.stage_id = PROJECTS.stage_id ON " +
                " TenderDatesInfo.proj_id = PROJECTS.proj_id INNER JOIN " +
                " TenderStatus ON PROJECTS.Tender_Status_id = TenderStatus.Tender_Status_id " +
                " WHERE (TenderStatus.Tender_Status_id not in (1, 6, 7, 8, 9, 10, 14, 15, 16)) AND " +
                " (TenderDatesInfo.stage_id = 2) AND (TenderDatesInfo.org_tenderbond_to_expire <=7) and (Year(TenderDatesInfo.org_tenderbond_validity)=YEAR(GETDATE()) OR YEAR(TenderDatesInfo.org_tenderbond_validity) = YEAR(GETDATE()) - 1)" +
                " AND (TenderDatesInfo.org_tenderbond_validity IS NOT NULL) AND (PROJECTS.tender_no LIKE '%DO%') and PROJECTS.committee_id=";


                sqlQueryForAlertReceived = "SELECT TenderDatesInfo.org_tenderbond_validity, TenderDatesInfo.tenderbond_validity_ext1,TenderDatesInfo.tenderbond_validity_ext2,PROJECTS.tender_no, PROJECTS.project_newname_en, " +
                "  PROJECTS.project_code,Committee.committee_short_name, TenderStatus.Status_Name," +
                " Department.Department, Committee.committee_id, TenderDatesInfo.proj_id" +
                " FROM TenderDatesInfo INNER JOIN STAGES INNER JOIN TenderTypes INNER JOIN " +
                " ContractTypes INNER JOIN FiscalYear INNER JOIN Committee INNER JOIN AFFAIRS INNER JOIN " +
                " PROJECTS ON AFFAIRS.Affair_id = PROJECTS.Affair_id ON Committee.committee_id = PROJECTS.committee_id ON " +
                " FiscalYear.FYID = PROJECTS.FYID ON ContractTypes.contract_type_id = PROJECTS.contract_type_id ON " +
                " TenderTypes.tender_type_id = PROJECTS.tender_type_id INNER JOIN " +
                " Department ON PROJECTS.department_id = Department.department_id ON STAGES.stage_id = PROJECTS.stage_id ON " +
                " TenderDatesInfo.proj_id = PROJECTS.proj_id INNER JOIN " +
                " TenderStatus ON PROJECTS.Tender_Status_id = TenderStatus.Tender_Status_id " +
                " WHERE (TenderStatus.Tender_Status_id not in (1, 6, 7, 8, 9, 10, 14, 15, 16)) AND " +
                " (TenderDatesInfo.stage_id = 2) AND (TenderDatesInfo.org_tenderbond_to_expire <=7) and (Year(TenderDatesInfo.org_tenderbond_validity)=YEAR(GETDATE()) OR YEAR(TenderDatesInfo.org_tenderbond_validity) = YEAR(GETDATE()) - 1) " +
                "AND TenderDatesInfo.Alert=1 AND (TenderDatesInfo.org_tenderbond_validity IS NOT NULL) AND (PROJECTS.tender_no LIKE '%DO%') AND PROJECTS.committee_id =";

                // Method for sending emails on Tender Bond Validity Expiration  
                SendEmailOnTenderBondValidityExpiry(sqlQueryForAlertNotReceived, sqlQueryForRecordCount, sqlQueryForAlertReceived);

                // Queries for sending emails on Tender Validity Expiration when Contract Info is present (For Non Direct Order Tender's)               

                string sqlQueryAlertNotRecWithContract = "SELECT TenderDatesInfo.org_tender_validity, TenderDatesInfo.tender_validity_ext1,TenderDatesInfo.tender_validity_ext2,PROJECTS.tender_no, PROJECTS.project_newname_en, " +
                "  PROJECTS.project_code,Committee.committee_short_name, TenderStatus.Status_Name," +
                " Department.Department, Committee.committee_id, TenderDatesInfo.proj_id " +
                " FROM TenderDatesInfo INNER JOIN STAGES INNER JOIN TenderTypes INNER JOIN " +
                " ContractTypes INNER JOIN FiscalYear INNER JOIN Committee RIGHT OUTER JOIN AFFAIRS INNER JOIN " +
                " PROJECTS ON AFFAIRS.Affair_id = PROJECTS.Affair_id ON Committee.committee_id = PROJECTS.committee_id ON " +
                " FiscalYear.FYID = PROJECTS.FYID ON ContractTypes.contract_type_id = PROJECTS.contract_type_id ON " +
                " TenderTypes.tender_type_id = PROJECTS.tender_type_id INNER JOIN " +
                " Department ON PROJECTS.department_id = Department.department_id ON STAGES.stage_id = PROJECTS.stage_id ON " +
                " TenderDatesInfo.proj_id = PROJECTS.proj_id INNER JOIN " +
                " TenderStatus ON PROJECTS.Tender_Status_id = TenderStatus.Tender_Status_id INNER JOIN CONTRACTORS ON PROJECTS.proj_id = CONTRACTORS.proj_id " +
                " WHERE (TenderStatus.Tender_Status_id not in (1, 7, 8, 9, 10, 14, 15, 16)) AND " +
                " (TenderDatesInfo.stage_id = 2) AND (TenderDatesInfo.org_tender_to_expire <=7) and (Year(TenderDatesInfo.org_tender_validity)=YEAR(GETDATE()) OR YEAR(TenderDatesInfo.org_tender_validity) = YEAR(GETDATE()) - 1) and (TenderDatesInfo.Alert=0 or TenderDatesInfo.Alert is NULL) " +
                "AND (CONTRACTORS.cp_contractor_sign IS NULL OR CONTRACTORS.cp_sent_dep_sign IS NULL) AND (TenderDatesInfo.org_tender_validity IS NOT NULL) AND (PROJECTS.tender_no NOT LIKE '%DO%') ORDER BY TenderDatesInfo.org_tender_validity DESC";

                string sqlQueryRecCountWithContract = "SELECT count(*)" +
                " FROM TenderDatesInfo INNER JOIN STAGES INNER JOIN TenderTypes INNER JOIN " +
                " ContractTypes INNER JOIN FiscalYear INNER JOIN Committee RIGHT OUTER JOIN AFFAIRS INNER JOIN " +
                " PROJECTS ON AFFAIRS.Affair_id = PROJECTS.Affair_id ON Committee.committee_id = PROJECTS.committee_id ON " +
                " FiscalYear.FYID = PROJECTS.FYID ON ContractTypes.contract_type_id = PROJECTS.contract_type_id ON " +
                " TenderTypes.tender_type_id = PROJECTS.tender_type_id INNER JOIN " +
                " Department ON PROJECTS.department_id = Department.department_id ON STAGES.stage_id = PROJECTS.stage_id ON " +
                " TenderDatesInfo.proj_id = PROJECTS.proj_id INNER JOIN " +
                " TenderStatus ON PROJECTS.Tender_Status_id = TenderStatus.Tender_Status_id INNER JOIN CONTRACTORS ON PROJECTS.proj_id = CONTRACTORS.proj_id " +
                " WHERE (TenderStatus.Tender_Status_id not in (1, 7, 8, 9, 10, 14, 15, 16)) AND " +
                " (TenderDatesInfo.stage_id = 2) AND (TenderDatesInfo.org_tender_to_expire <=7) and (Year(TenderDatesInfo.org_tender_validity)=YEAR(GETDATE()) OR YEAR(TenderDatesInfo.org_tender_validity) = YEAR(GETDATE()) - 1)" +
                " AND (TenderDatesInfo.org_tender_validity IS NOT NULL) AND (PROJECTS.tender_no NOT LIKE '%DO%') and PROJECTS.committee_id=";

                string sqlQueryAlertRecWithContract = "SELECT TenderDatesInfo.org_tender_validity, TenderDatesInfo.tender_validity_ext1,TenderDatesInfo.tender_validity_ext2,PROJECTS.tender_no, PROJECTS.project_newname_en, " +
                "  PROJECTS.project_code,Committee.committee_short_name, TenderStatus.Status_Name," +
                " Department.Department, Committee.committee_id, TenderDatesInfo.proj_id" +
                " FROM TenderDatesInfo INNER JOIN STAGES INNER JOIN TenderTypes INNER JOIN " +
                " ContractTypes INNER JOIN FiscalYear INNER JOIN Committee RIGHT OUTER JOIN AFFAIRS INNER JOIN " +
                " PROJECTS ON AFFAIRS.Affair_id = PROJECTS.Affair_id ON Committee.committee_id = PROJECTS.committee_id ON " +
                " FiscalYear.FYID = PROJECTS.FYID ON ContractTypes.contract_type_id = PROJECTS.contract_type_id ON " +
                " TenderTypes.tender_type_id = PROJECTS.tender_type_id INNER JOIN " +
                " Department ON PROJECTS.department_id = Department.department_id ON STAGES.stage_id = PROJECTS.stage_id ON " +
                " TenderDatesInfo.proj_id = PROJECTS.proj_id INNER JOIN " +
                " TenderStatus ON PROJECTS.Tender_Status_id = TenderStatus.Tender_Status_id INNER JOIN CONTRACTORS ON PROJECTS.proj_id = CONTRACTORS.proj_id " +
                " WHERE (TenderStatus.Tender_Status_id not in (1, 7, 8, 9, 10, 14, 15, 16)) AND " +
                " (TenderDatesInfo.stage_id = 2) AND (TenderDatesInfo.org_tender_to_expire <=7) and (Year(TenderDatesInfo.org_tender_validity)=YEAR(GETDATE()) OR YEAR(TenderDatesInfo.org_tender_validity) = YEAR(GETDATE()) - 1) " +
                "AND TenderDatesInfo.Alert=1 AND (TenderDatesInfo.org_tender_validity IS NOT NULL) AND (PROJECTS.tender_no NOT LIKE '%DO%') AND PROJECTS.committee_id =";

                // Method for sending emails on Tender Validity Expiration  
                SendEmailOnTenderValidityExpiry(sqlQueryAlertNotRecWithContract,sqlQueryRecCountWithContract,sqlQueryAlertRecWithContract);

                // Queries for sending emails on Tender Validity Expiration when Contract Info is not present (For Direct Order Tender's)                
                sqlQueryAlertNotRecWithContract = "SELECT TenderDatesInfo.org_tender_validity, TenderDatesInfo.tender_validity_ext1,TenderDatesInfo.tender_validity_ext2,PROJECTS.tender_no, PROJECTS.project_newname_en, " +
                "  PROJECTS.project_code,Committee.committee_short_name, TenderStatus.Status_Name," +
                " Department.Department, Committee.committee_id, TenderDatesInfo.proj_id " +
                " FROM TenderDatesInfo INNER JOIN STAGES INNER JOIN TenderTypes INNER JOIN " +
                " ContractTypes INNER JOIN FiscalYear INNER JOIN Committee RIGHT OUTER JOIN AFFAIRS INNER JOIN " +
                " PROJECTS ON AFFAIRS.Affair_id = PROJECTS.Affair_id ON Committee.committee_id = PROJECTS.committee_id ON " +
                " FiscalYear.FYID = PROJECTS.FYID ON ContractTypes.contract_type_id = PROJECTS.contract_type_id ON " +
                " TenderTypes.tender_type_id = PROJECTS.tender_type_id INNER JOIN " +
                " Department ON PROJECTS.department_id = Department.department_id ON STAGES.stage_id = PROJECTS.stage_id ON " +
                " TenderDatesInfo.proj_id = PROJECTS.proj_id INNER JOIN " +
                " TenderStatus ON PROJECTS.Tender_Status_id = TenderStatus.Tender_Status_id " +
                " WHERE (TenderStatus.Tender_Status_id not in (1, 6, 7, 8, 9, 10, 14, 15, 16)) AND " +
                " (TenderDatesInfo.stage_id = 2) AND (TenderDatesInfo.org_tender_to_expire <=7) and (Year(TenderDatesInfo.org_tender_validity)=YEAR(GETDATE()) OR YEAR(TenderDatesInfo.org_tender_validity) = YEAR(GETDATE()) - 1) and (TenderDatesInfo.Alert=0 or TenderDatesInfo.Alert is NULL) " +
                "AND (TenderDatesInfo.org_tender_validity IS NOT NULL) AND (PROJECTS.tender_no LIKE '%DO%') ORDER BY TenderDatesInfo.org_tender_validity DESC";

                sqlQueryRecCountWithContract = "SELECT count(*)" +
                " FROM TenderDatesInfo INNER JOIN STAGES INNER JOIN TenderTypes INNER JOIN " +
                " ContractTypes INNER JOIN FiscalYear INNER JOIN Committee RIGHT OUTER JOIN AFFAIRS INNER JOIN " +
                " PROJECTS ON AFFAIRS.Affair_id = PROJECTS.Affair_id ON Committee.committee_id = PROJECTS.committee_id ON " +
                " FiscalYear.FYID = PROJECTS.FYID ON ContractTypes.contract_type_id = PROJECTS.contract_type_id ON " +
                " TenderTypes.tender_type_id = PROJECTS.tender_type_id INNER JOIN " +
                " Department ON PROJECTS.department_id = Department.department_id ON STAGES.stage_id = PROJECTS.stage_id ON " +
                " TenderDatesInfo.proj_id = PROJECTS.proj_id INNER JOIN " +
                " TenderStatus ON PROJECTS.Tender_Status_id = TenderStatus.Tender_Status_id " +
                " WHERE (TenderStatus.Tender_Status_id not in (1, 6, 7, 8, 9, 10, 14, 15, 16)) AND " +
                " (TenderDatesInfo.stage_id = 2) AND (TenderDatesInfo.org_tender_to_expire <=7) and (Year(TenderDatesInfo.org_tender_validity)=YEAR(GETDATE()) OR YEAR(TenderDatesInfo.org_tender_validity) = YEAR(GETDATE()) - 1)" +
                " AND (TenderDatesInfo.org_tender_validity IS NOT NULL) AND (PROJECTS.tender_no LIKE '%DO%') and PROJECTS.committee_id=";

                sqlQueryAlertRecWithContract = "SELECT TenderDatesInfo.org_tender_validity, TenderDatesInfo.tender_validity_ext1,TenderDatesInfo.tender_validity_ext2,PROJECTS.tender_no, PROJECTS.project_newname_en, " +
                "  PROJECTS.project_code,Committee.committee_short_name, TenderStatus.Status_Name," +
                " Department.Department, Committee.committee_id, TenderDatesInfo.proj_id" +
                " FROM TenderDatesInfo INNER JOIN STAGES INNER JOIN TenderTypes INNER JOIN " +
                " ContractTypes INNER JOIN FiscalYear INNER JOIN Committee RIGHT OUTER JOIN AFFAIRS INNER JOIN " +
                " PROJECTS ON AFFAIRS.Affair_id = PROJECTS.Affair_id ON Committee.committee_id = PROJECTS.committee_id ON " +
                " FiscalYear.FYID = PROJECTS.FYID ON ContractTypes.contract_type_id = PROJECTS.contract_type_id ON " +
                " TenderTypes.tender_type_id = PROJECTS.tender_type_id INNER JOIN " +
                " Department ON PROJECTS.department_id = Department.department_id ON STAGES.stage_id = PROJECTS.stage_id ON " + 
                " TenderDatesInfo.proj_id = PROJECTS.proj_id INNER JOIN " +
                " TenderStatus ON PROJECTS.Tender_Status_id = TenderStatus.Tender_Status_id " +
                " WHERE (TenderStatus.Tender_Status_id not in (1, 6, 7, 8, 9, 10, 14, 15, 16)) AND " +
                " (TenderDatesInfo.stage_id = 2) AND (TenderDatesInfo.org_tender_to_expire <=7) and (Year(TenderDatesInfo.org_tender_validity)=YEAR(GETDATE()) OR YEAR(TenderDatesInfo.org_tender_validity) = YEAR(GETDATE()) - 1) " +
                "AND TenderDatesInfo.Alert=1 AND (TenderDatesInfo.org_tender_validity IS NOT NULL) AND (PROJECTS.tender_no LIKE '%DO%') AND PROJECTS.committee_id =";
                 
                // Method for sending emails on Tender Validity Expiration 
                SendEmailOnTenderValidityExpiry(sqlQueryAlertNotRecWithContract,sqlQueryRecCountWithContract,sqlQueryAlertRecWithContract);

                 
            }
            catch (DocumentException dex)
            {
                WriteToLog(DateTime.Now + "::" + "Error occurred while creating the pdf file" + "::" + dex.Message);
            }
            catch (IOException ioex)
            {
                //Handle IO exception //"Exception occurred while creating the pdf file"
                WriteToLog(DateTime.Now + "::" + "Error occurred while creating the pdf file" + "::" + ioex.Message);
            }
            catch (Exception ex)
            {
                WriteToLog(DateTime.Now + "::" + "Error occurred while creating the pdf file" + "::" + ex.Message);
            }
        
        }

        private void SendEmailOnTenderValidityExpiry(string sqlQueryAlertNotRecWithContract, string sqlQueryRecCountWithContract, string sqlQueryAlertRecWithContract)
        {            

            DAL dalObj = new DAL();
            DataTable dtTenderValidityExp = dalObj.GetDataFromDB("TenderValidityExpiry", sqlQueryAlertNotRecWithContract);

            if (dtTenderValidityExp.Rows.Count != 0)
            {

                for (Int16 iComtyCounter = 1; iComtyCounter <= 7; iComtyCounter++) // 7 = Number of Committees 
                {
                    DataRow[] drTenderValidityExpAlertNotReceived = dtTenderValidityExp.Select("committee_id=" + iComtyCounter);

                    if (drTenderValidityExpAlertNotReceived.Length != 0)
                    {
                        string sqlQuery = "SELECT DISTINCT USERS.email_address,EmailAlertRecipients.user_id, USERS.user_name, EmailAlertCategory.AlertCategory, EmailAlertRecipients.alert_cat_id, " +
                        " Committee.committee_short_name FROM EmailAlertCategory INNER JOIN EmailAlertRecipients ON EmailAlertCategory.alert_cat_id = EmailAlertRecipients.alert_cat_id INNER JOIN " +
                        " USERS ON EmailAlertRecipients.user_id = USERS.user_id INNER JOIN Committee ON EmailAlertRecipients.committee_id = Committee.committee_id " +
                        " WHERE (EmailAlertRecipients.alert_cat_id = 4) AND (USERS.email_address <> N'') AND (Committee.committee_id =" + iComtyCounter + ")";
                        UserList_ForAlert(sqlQuery);

                        if (userListColl.Count == 0)
                        {
                            UserList_ForAlert("SELECT DISTINCT USERS.email_address from USERS where user_profile_id=1 AND (email_address <> '')");                            

                            string emailIds = string.Join(",", userListColl.ToArray()); //.Replace(",", ";");

                            MailMessage mailMessage = new MailMessage();
                            mailMessage.From = new MailAddress(ConfigurationManager.AppSettings["adminEmailID"].ToString());
                            foreach (var address in emailIds.ToString().Split(new[] { "," }, StringSplitOptions.RemoveEmptyEntries))
                            {
                                mailMessage.To.Add(address);
                            }
                                
                            mailMessage.Subject = "TCMS Alert: Tender Validity Alert Message";

                            mailMessage.Body = "\n" +
                            "This is an automated alert from TCMS." + "\n" +
                            "\n" +
                            "Tender Validity Expiry program is about to sent an alert message to " + drTenderValidityExpAlertNotReceived[0].ItemArray[4] + " but there is no identified user to receive the email.\n" +
                            "\n";

                            SmtpClient client = new SmtpClient();
                            client.EnableSsl = true;
                            client.Credentials = new System.Net.NetworkCredential(@"tcms", ConfigurationManager.AppSettings["emailPass"].ToString());
                            ServicePointManager.ServerCertificateValidationCallback = delegate(object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };
                            client.Host = ConfigurationManager.AppSettings["SmtpHostIP"].ToString();
                            client.Port = Convert.ToInt32(ConfigurationManager.AppSettings["SmtpHostPort"]);
                            client.Send(mailMessage);
                            
                            return;
                        }

                        string modifiedSqlQueryRecCountWithContract = sqlQueryRecCountWithContract + iComtyCounter;

                        DataTable dtTotValidityExpPerCommittee = dalObj.GetDataFromDB("TotalTenderValidityExpPerCommittee", modifiedSqlQueryRecCountWithContract);

                        DataTable dtTotalTenderValidityExpiry = new DataTable();
                        dtTotalTenderValidityExpiry.Columns.Add("TenderValidityDate");
                        dtTotalTenderValidityExpiry.Columns.Add("TenderNo");
                        dtTotalTenderValidityExpiry.Columns.Add("ProjectTitle");
                        dtTotalTenderValidityExpiry.Columns.Add("ProjectCode");
                        dtTotalTenderValidityExpiry.Columns.Add("TenderCommittee");
                        dtTotalTenderValidityExpiry.Columns.Add("TenderStatus");
                        dtTotalTenderValidityExpiry.Columns.Add("UserDepartment");
                        dtTotalTenderValidityExpiry.Columns.Add("ProjId");
                        dtTotalTenderValidityExpiry.AcceptChanges();

                        foreach (DataRow drProj in drTenderValidityExpAlertNotReceived)
                        {
                            DataRow dr = dtTotalTenderValidityExpiry.NewRow();
                            if (drProj[2] != DBNull.Value)
                            {
                                dr[0] = drProj[2].ToString().Split(' ')[0];  //tenderbond_validitydate
                            }
                            else if (drProj[1] != DBNull.Value)
                            {
                                dr[0] = drProj[1].ToString().Split(' ')[0];  //tenderbond_validitydate
                            }
                            else
                            {
                                dr[0] = drProj[0].ToString().Split(' ')[0];  //tenderbond_validitydate
                            }
                            dr[1] = drProj[3];  //TenderNo
                            dr[2] = drProj[4];  //ProjectTitle
                            dr[3] = drProj[5];  //ProjectCode
                            dr[4] = drProj[6];  //TenderCommittee
                            dr[5] = drProj[7];  //TenderStatus
                            dr[6] = drProj[8];  //UserDepartment       
                            dr[7] = drProj[9];  //ProjId
                            dtTotalTenderValidityExpiry.Rows.Add(dr);
                            dtTotalTenderValidityExpiry.AcceptChanges();
                        }

                        string modifiedSqlQueryAlertRecWithContract = sqlQueryAlertRecWithContract + iComtyCounter + " ORDER BY TenderDatesInfo.org_tender_validity DESC";

                        DataTable dtTenderValidityExpForAlertsReceived = dalObj.GetDataFromDB("TenderValidityExpForAlertsReceived", modifiedSqlQueryAlertRecWithContract);
                                               
                        foreach (DataRow drForAlertsReceived in dtTenderValidityExpForAlertsReceived.Rows)
                        {
                            DataRow dr = dtTotalTenderValidityExpiry.NewRow();
                            if (drForAlertsReceived[2] != DBNull.Value)
                            {
                                dr[0] = drForAlertsReceived[2].ToString().Split(' ')[0];  //tenderbond_validitydate
                            }
                            else if (drForAlertsReceived[1] != DBNull.Value)
                            {
                                dr[0] = drForAlertsReceived[1].ToString().Split(' ')[0];  //tenderbond_validitydate
                            }
                            else
                            {
                                dr[0] = drForAlertsReceived[0].ToString().Split(' ')[0];  //tenderbond_validitydate
                            }
                            dr[1] = drForAlertsReceived[3];  //TenderNo
                            dr[2] = drForAlertsReceived[4];  //ProjectTitle
                            dr[3] = drForAlertsReceived[5];  //ProjectCode
                            dr[4] = drForAlertsReceived[6];  //TenderCommittee
                            dr[5] = drForAlertsReceived[7];  //TenderStatus
                            dr[6] = drForAlertsReceived[8];  //UserDepartment       
                            dr[7] = drForAlertsReceived[9];  //ProjId
                            dtTotalTenderValidityExpiry.Rows.Add(dr);
                            dtTotalTenderValidityExpiry.AcceptChanges();
                        }
                        
                        StringBuilder strBuild = null;
                        mStream = new MemoryStream();
                        try
                        {
                            byte[] newPdf = null;
                            iTextSharp.text.Font headerText = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.TIMES_ROMAN, 12f);
                            iTextSharp.text.Font plainText = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.TIMES_ROMAN, 8f);

                            using (var pdfMemStream = new MemoryStream())
                            {
                                var doc = new Document(iTextSharp.text.PageSize.A4);
                                using (PdfWriter writer = PdfWriter.GetInstance(doc, pdfMemStream))
                                {
                                    doc.AddAuthor("PWA-ASHGHAL");
                                    doc.AddCreator("TCMS-APP");
                                    //doc.AddTitle(sNrOferty);
                                    PageEventHelper pageEventHelper = new PageEventHelper();
                                    writer.PageEvent = pageEventHelper;
                                    doc.Open();

                                    BaseFont bfArialItemNames = BaseFont.CreateFont(@"C:\Windows\Fonts\arial.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
                                    iTextSharp.text.Font companyNameFont = new iTextSharp.text.Font(bfArialItemNames, 10f, Font.NORMAL, iTextSharp.text.BaseColor.BLUE);                                     
                                    iTextSharp.text.Image pngImg = null;                                     
                                    pngImg = iTextSharp.text.Image.GetInstance(ashLogoImage);
                                    pngImg.ScaleToFit(540f, 540f);
                                    doc.Add(pngImg);                                     

                                    PdfPTable pdfTable = new PdfPTable(7);
                                    pdfTable.TotalWidth = 555f;
                                    pdfTable.LockedWidth = true;
                                    pdfTable.SpacingBefore = 25f;
                                    float[] widths = new float[] { 11f, 23f, 27f, 16f, 10f, 13f, 18f };
                                    //float[] widths = new float[] { 8f, 22f, 27f, 16f, 10f, 13f, 17f,10f,10f };                                    

                                    Chunk ch = new Chunk("List of Projects where Tender Validity Expiration is Less than 7 or negative expired days", headerText);
                                    Chunk boldCh4 = new Chunk("                                            Project Count =" + dtTotValidityExpPerCommittee.Rows[0][0], plainText);
                                    Phrase p1 = new Phrase(ch);
                                    p1.Add(boldCh4);
                                    Paragraph pg4 = new Paragraph();
                                    pg4.Add(p1);
                                    pg4.SpacingAfter = 10f;
                                    doc.Add(pg4);

                                    pdfTable.SetWidths(widths);
                                    pdfTable = createTable(dtTotalTenderValidityExpiry, pdfTable);
                                    doc.Add(pdfTable);
                                    doc.Close();
                                    newPdf = pdfMemStream.GetBuffer();
                                }
                            }

                            strBuild = new StringBuilder();
                            mStream.Write(newPdf, 0, newPdf.Length);
                            mStream.Position = 0;

                            //string DisplayName = ""; string Email = ""; string Department = ""; string Title = "";

                            // AlertOnNewTenderNo(tenderNo, _projID.ToString(), "New Project");

                            //string fromUser = string.Empty;                             
                            //fromUser = "ebsd_vpuchnanda";                            

                            //if (GetUserInformation4rmActiveDirectory(fromUser, "ashghal.gov.qa", ref user_DisplayName, ref user_Email, ref  user_Department, ref user_Title) == true)
                            //{
                            string emailIds = string.Join(",", userListColl.ToArray()); //.Replace(",", ";");
                         
                            MailMessage mailMessage = new MailMessage();                             
                            mailMessage.From = new MailAddress(ConfigurationManager.AppSettings["adminEmailID"].ToString());
                            Int16 emailCounter = 0;
                            foreach (var address in emailIds.ToString().Split(new[] { "," }, StringSplitOptions.RemoveEmptyEntries))
                            {
                                if (emailCounter <= 4)
                                {
                                    mailMessage.To.Add(address);
                                    emailCounter++;
                                }
                                else
                                    break;
                            }
                        
                            //mailMessage.To.Add(new MailAddress(strname));
                            mailMessage.Subject = "TCMS Alert: Updated list of " + dtTotalTenderValidityExpiry.Rows[0][4] + " Projects where Tender Validity Will Expire in less than 7 or negative Days";
                            System.Net.Mime.ContentType ct = new System.Net.Mime.ContentType(System.Net.Mime.MediaTypeNames.Application.Pdf);
                            Attachment attach = new Attachment(mStream, ct);//strBuild.ToString()); // Regex.Replace(strBuild.ToString(), @"\\", @"/")                                   
                            attach.ContentDisposition.FileName = "Tender Validity Expiration Per Committee.pdf";
                            mailMessage.Attachments.Add(attach);

                            if (drTenderValidityExpAlertNotReceived.Length == 1)
                            {
                                mailMessage.Body = "\n" +
                                "This is an automated alert from TCMS." + "\n" +
                                "\n" +
                                drTenderValidityExpAlertNotReceived.Length + " Project is added in the list of " + dtTotalTenderValidityExpiry.Rows[0][4] + " where Tender Validity will expire in less than 7 or negative days. Attached is the updated list for your \n" +
                                "information. Total count of project in the updated list is " + dtTotValidityExpPerCommittee.Rows[0][0] + ".\n" +
                                "\n";
                            }
                            else
                            {
                                mailMessage.Body = "\n" +
                                "This is an automated alert from TCMS." + "\n" +
                                "\n" +
                                drTenderValidityExpAlertNotReceived.Length + " Projects are added in the list of " + dtTotalTenderValidityExpiry.Rows[0][4] + " where Tender Validity will expire in less than 7 or negative days. Attached is the updated list for your \n" +
                                "information. Total count of project in the updated list is " + dtTotValidityExpPerCommittee.Rows[0][0] + ".\n" +
                                "\n";
                            }                                     

                            SmtpClient client = new SmtpClient();
                            client.EnableSsl = true;
                            client.Credentials = new System.Net.NetworkCredential(@"tcms", ConfigurationManager.AppSettings["emailPass"].ToString());
                            ServicePointManager.ServerCertificateValidationCallback = delegate(object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };
                            client.Host = ConfigurationManager.AppSettings["SmtpHostIP"].ToString();
                            client.Port = Convert.ToInt32(ConfigurationManager.AppSettings["SmtpHostPort"]);
                            client.Send(mailMessage);
                            mStream.Position = 0;                         


                            Int16 tndrBondExpiryWithoutAlertCounter = 0;
                            using (SqlConnection sqlCn = new SqlConnection(strConn))
                            {
                                sqlCn.Open();
                                while (tndrBondExpiryWithoutAlertCounter < dtTotalTenderValidityExpiry.Rows.Count)
                                {
                                    string sqlUpdateAlertStatusQuery = "Update TenderDatesInfo set TenderDatesInfo.Alert = 1" +
                                    " where  TenderDatesInfo.proj_id =" + dtTotalTenderValidityExpiry.Rows[tndrBondExpiryWithoutAlertCounter][7];
                                    dalObj.ExecuteNonQuery(sqlUpdateAlertStatusQuery, sqlCn);
                                    tndrBondExpiryWithoutAlertCounter++;

                                }
                                sqlCn.Close();
                            }

                            WriteToLog(DateTime.Now + "::" + "Successfully send the email notification to Tender Committee and updated the alert status for Expiration of Tender Validity");
                            //}
                        }
                        catch (Exception ex)
                        {
                            WriteToLog(DateTime.Now + "::" + "Error occurred while sending the email notification to a member of Tender Committee" + "::" + ex.Message);
                        }
                    }
                }
            }
        }
        private void SendEmailOnTenderBondValidityExpiry(string sqlQueryForAlertNotReceived, string sqlQueryForRecordCount, string sqlQueryForAlertReceived)
        {
            

            DAL dalObj = new DAL();
            DataTable dtTenderBondExp = dalObj.GetDataFromDB("TenderBondExpiry", sqlQueryForAlertNotReceived);

            if (dtTenderBondExp.Rows.Count != 0)
            {

                for (Int16 iComtyCounter = 1; iComtyCounter <= 7; iComtyCounter++) // 7 = Number of Committees 
                {
                    DataRow[] drTenderBondExpAlertNotReceived = dtTenderBondExp.Select("committee_id=" + iComtyCounter);

                    if (drTenderBondExpAlertNotReceived.Length != 0)
                    {
                        string sqlQuery = "SELECT DISTINCT USERS.email_address,EmailAlertRecipients.user_id, USERS.user_name, EmailAlertCategory.AlertCategory, EmailAlertRecipients.alert_cat_id, " +
                       " Committee.committee_short_name FROM EmailAlertCategory INNER JOIN EmailAlertRecipients ON EmailAlertCategory.alert_cat_id = EmailAlertRecipients.alert_cat_id INNER JOIN " +
                       " USERS ON EmailAlertRecipients.user_id = USERS.user_id INNER JOIN Committee ON EmailAlertRecipients.committee_id = Committee.committee_id " +
                       " WHERE (EmailAlertRecipients.alert_cat_id = 4) AND (USERS.email_address <> N'') AND (Committee.committee_id =" + iComtyCounter + ")";
                        UserList_ForAlert(sqlQuery);

                        if (userListColl.Count == 0)
                        {
                            UserList_ForAlert("SELECT DISTINCT USERS.email_address from USERS where user_profile_id=1 AND (email_address <> '')");

                            
                            foreach (string strname in userListColl)
                            {

                                MailMessage mailMessage = new MailMessage();

                                mailMessage.From = new MailAddress(ConfigurationManager.AppSettings["adminEmailID"].ToString());
                                mailMessage.To.Add(new MailAddress(strname));
                                mailMessage.Subject = "TCMS Alert: Tender Bond Validity Alert Message";

                                mailMessage.Body = "\n" +
                                "This is an automated alert from TCMS." + "\n" +
                                "\n" +
                                "Tender Validity Expiry program is about to sent an alert message to " + drTenderBondExpAlertNotReceived[0].ItemArray[4] + " but there is no identified user to receive the email.\n" +
                                "\n";

                                SmtpClient client = new SmtpClient();
                                client.EnableSsl = true;
                                client.Credentials = new System.Net.NetworkCredential(@"tcms", ConfigurationManager.AppSettings["emailPass"].ToString());
                                ServicePointManager.ServerCertificateValidationCallback = delegate(object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };
                                client.Host = ConfigurationManager.AppSettings["SmtpHostIP"].ToString();
                                client.Port = Convert.ToInt32(ConfigurationManager.AppSettings["SmtpHostPort"]);
                                client.Send(mailMessage);

                            }
                            return;
                        }

                        string modifiedSqlQueryForRecordCount = sqlQueryForRecordCount + iComtyCounter;

                        DataTable dtTotBondExpPerCommittee = dalObj.GetDataFromDB("TotalTenderBondsExpPerCommittee", modifiedSqlQueryForRecordCount);

                        DataTable dtTotalTenderBondExpiry = new DataTable();
                        dtTotalTenderBondExpiry.Columns.Add("TenderValidityDate");
                        dtTotalTenderBondExpiry.Columns.Add("TenderNo");
                        dtTotalTenderBondExpiry.Columns.Add("ProjectTitle");
                        dtTotalTenderBondExpiry.Columns.Add("ProjectCode");
                        dtTotalTenderBondExpiry.Columns.Add("TenderCommittee");
                        dtTotalTenderBondExpiry.Columns.Add("TenderStatus");
                        dtTotalTenderBondExpiry.Columns.Add("UserDepartment");
                        dtTotalTenderBondExpiry.Columns.Add("ProjId");
                        dtTotalTenderBondExpiry.AcceptChanges();

                        foreach (DataRow drProj in drTenderBondExpAlertNotReceived)
                        {
                            DataRow dr = dtTotalTenderBondExpiry.NewRow();
                            if (drProj[2] != DBNull.Value)
                            {
                                dr[0] = drProj[2].ToString().Split(' ')[0];  //tenderbond_validitydate
                            }
                            else if (drProj[1] != DBNull.Value)
                            {
                                dr[0] = drProj[1].ToString().Split(' ')[0];  //tenderbond_validitydate
                            }
                            else
                            {
                                dr[0] = drProj[0].ToString().Split(' ')[0];  //tenderbond_validitydate
                            }
                            dr[1] = drProj[3];  //TenderNo
                            dr[2] = drProj[4];  //ProjectTitle
                            dr[3] = drProj[5];  //ProjectCode
                            dr[4] = drProj[6];  //TenderCommittee
                            dr[5] = drProj[7];  //TenderStatus
                            dr[6] = drProj[8];  //UserDepartment       
                            dr[7] = drProj[9];  //ProjId
                            dtTotalTenderBondExpiry.Rows.Add(dr);
                            dtTotalTenderBondExpiry.AcceptChanges();
                        }

                        string modifiedSqlQueryForAlertReceived = sqlQueryForAlertReceived + iComtyCounter + " ORDER BY TenderDatesInfo.org_tenderbond_validity DESC";

                        DataTable dtTenderBondsExpForAlertsReceived = dalObj.GetDataFromDB("TenderBondsExpForAlertsReceived", modifiedSqlQueryForAlertReceived);

                        foreach (DataRow drForAlertsReceived in dtTenderBondsExpForAlertsReceived.Rows)
                        {
                            DataRow dr = dtTotalTenderBondExpiry.NewRow();
                            if (drForAlertsReceived[2] != DBNull.Value)
                            {
                                dr[0] = drForAlertsReceived[2].ToString().Split(' ')[0];  //tenderbond_validitydate
                            }
                            else if (drForAlertsReceived[1] != DBNull.Value)
                            {
                                dr[0] = drForAlertsReceived[1].ToString().Split(' ')[0];  //tenderbond_validitydate
                            }
                            else
                            {
                                dr[0] = drForAlertsReceived[0].ToString().Split(' ')[0];  //tenderbond_validitydate
                            }
                            dr[1] = drForAlertsReceived[3];  //TenderNo
                            dr[2] = drForAlertsReceived[4];  //ProjectTitle
                            dr[3] = drForAlertsReceived[5];  //ProjectCode
                            dr[4] = drForAlertsReceived[6];  //TenderCommittee
                            dr[5] = drForAlertsReceived[7];  //TenderStatus
                            dr[6] = drForAlertsReceived[8];  //UserDepartment       
                            dr[7] = drForAlertsReceived[9];  //ProjId
                            dtTotalTenderBondExpiry.Rows.Add(dr);
                            dtTotalTenderBondExpiry.AcceptChanges();
                        }

                        StringBuilder strBuild = null;
                        mStream = new MemoryStream();
                        try
                        {
                            byte[] newPdf = null;
                            iTextSharp.text.Font headerText = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.TIMES_ROMAN, 12f);
                            iTextSharp.text.Font plainText = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.TIMES_ROMAN, 8f);

                            using (var pdfMemStream = new MemoryStream())
                            {
                                var doc = new Document(iTextSharp.text.PageSize.A4);
                                using (PdfWriter writer = PdfWriter.GetInstance(doc, pdfMemStream))
                                {
                                    doc.AddAuthor("PWA-ASHGHAL");
                                    doc.AddCreator("TCMS-APP");
                                    //doc.AddTitle(sNrOferty);
                                    PageEventHelper pageEventHelper = new PageEventHelper();
                                    writer.PageEvent = pageEventHelper;
                                    doc.Open();
                                     
                                    BaseFont bfArialItemNames = BaseFont.CreateFont(@"C:\Windows\Fonts\arial.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
                                    iTextSharp.text.Font companyNameFont = new iTextSharp.text.Font(bfArialItemNames, 10f, Font.NORMAL, iTextSharp.text.BaseColor.BLUE);                                     
                                    iTextSharp.text.Image pngImg = null;
                                    pngImg = iTextSharp.text.Image.GetInstance(ashLogoImage);
                                    pngImg.ScaleToFit(540f, 540f);
                                    doc.Add(pngImg);
                                     

                                    PdfPTable pdfTable = new PdfPTable(7);
                                    pdfTable.TotalWidth = 555f;
                                    pdfTable.LockedWidth = true;
                                    pdfTable.SpacingBefore = 25f;
                                    float[] widths = new float[] { 9f, 23f, 27f, 16f, 10f, 13f, 19f };
                                    //float[] widths = new float[] { 8f, 22f, 27f, 16f, 10f, 13f, 17f,10f,10f };                                    

                                    Chunk ch = new Chunk("List of Projects where Tender Validity Expiration is Less than 7 or negative expired days", headerText);
                                    Chunk boldCh4 = new Chunk("                                            Project Count =" + dtTotBondExpPerCommittee.Rows[0][0], plainText);
                                    Phrase p1 = new Phrase(ch);
                                    p1.Add(boldCh4);
                                    Paragraph pg4 = new Paragraph();
                                    pg4.Add(p1);
                                    pg4.SpacingAfter = 10f;
                                    doc.Add(pg4);

                                    pdfTable.SetWidths(widths);
                                    pdfTable = createTable(dtTotalTenderBondExpiry, pdfTable);
                                    doc.Add(pdfTable);
                                    doc.Close();
                                    newPdf = pdfMemStream.GetBuffer();
                                }
                            }

                            strBuild = new StringBuilder();
                            mStream.Write(newPdf, 0, newPdf.Length);
                            mStream.Position = 0;

                            //string DisplayName = ""; string Email = ""; string Department = ""; string Title = "";

                            // AlertOnNewTenderNo(tenderNo, _projID.ToString(), "New Project");

                            //string fromUser = string.Empty;                             
                            //fromUser = "ebsd_vpuchnanda";                            

                            //if (GetUserInformation4rmActiveDirectory(fromUser, "ashghal.gov.qa", ref user_DisplayName, ref user_Email, ref  user_Department, ref user_Title) == true)
                            //{
                            //string emailIds = userListColl.ToString();
                            string emailIds = string.Join(",", userListColl.ToArray()); //.Replace(",", ";");
                           
                                MailMessage mailMessage = new MailMessage();

                                mailMessage.From = new MailAddress(ConfigurationManager.AppSettings["adminEmailID"].ToString());                            
                                mailMessage.To.Clear();
                                foreach (var address in emailIds.ToString().Split(new[] { "," }, StringSplitOptions.RemoveEmptyEntries)) 
                                {
                                    mailMessage.To.Add(address);
                                }
                                //mailMessage.To.Add(new MailAddress(emailIds));
                                mailMessage.Subject = "TCMS Alert: Updated list of " + dtTotalTenderBondExpiry.Rows[0][4] + " Projects where Tender Bond Validity Will Expire in less than 7 or negative Days";
                                System.Net.Mime.ContentType ct = new System.Net.Mime.ContentType(System.Net.Mime.MediaTypeNames.Application.Pdf);
                                Attachment attach = new Attachment(mStream, ct);//strBuild.ToString()); // Regex.Replace(strBuild.ToString(), @"\\", @"/")                                   
                                attach.ContentDisposition.FileName = "Tender Bond Validity Expiration Per Committee.pdf";
                                mailMessage.Attachments.Add(attach);

                                if (drTenderBondExpAlertNotReceived.Length == 1)
                                {
                                    mailMessage.Body = "\n" +
                                    "This is an automated alert from TCMS." + "\n" +
                                    "\n" +
                                    drTenderBondExpAlertNotReceived.Length + " Project is added in the list of " + dtTotalTenderBondExpiry.Rows[0][4] + " where Tender Bond Validity will expire in less than 7 or negative days. Attached is the updated list for your \n" +
                                    "information. Total count of project in the updated list is " + dtTotBondExpPerCommittee.Rows[0][0] + ".\n" +
                                    "\n";
                                }
                                else
                                {
                                    mailMessage.Body = "\n" +
                                   "This is an automated alert from TCMS." + "\n" +
                                   "\n" +
                                   drTenderBondExpAlertNotReceived.Length + " Projects are added in the list of " + dtTotalTenderBondExpiry.Rows[0][4] + " where Tender Bond Validity will expire in less than 7 days. Attached is the updated list for your \n" +
                                   "information. Total count of project in the updated list is " + dtTotBondExpPerCommittee.Rows[0][0] + ".\n" +
                                   "\n";
                                }                                

                                SmtpClient client = new SmtpClient();
                                client.EnableSsl = true;
                                client.Credentials = new System.Net.NetworkCredential(@"tcms", ConfigurationManager.AppSettings["emailPass"].ToString());
                                ServicePointManager.ServerCertificateValidationCallback = delegate(object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };
                                client.Host = ConfigurationManager.AppSettings["SmtpHostIP"].ToString();
                                client.Port = Convert.ToInt32(ConfigurationManager.AppSettings["SmtpHostPort"]);
                                client.Send(mailMessage);
                                mStream.Position = 0;

                            //}


                            Int16 tndrBondExpiryWithoutAlertCounter = 0;
                            using (SqlConnection sqlCn = new SqlConnection(strConn))
                            {
                                sqlCn.Open();
                                while (tndrBondExpiryWithoutAlertCounter < dtTotalTenderBondExpiry.Rows.Count)
                                {
                                    string sqlUpdateAlertStatusQuery = "Update TenderDatesInfo set TenderDatesInfo.Alert = 1" +
                                    " where  TenderDatesInfo.proj_id =" + dtTotalTenderBondExpiry.Rows[tndrBondExpiryWithoutAlertCounter][7];
                                    dalObj.ExecuteNonQuery(sqlUpdateAlertStatusQuery, sqlCn);
                                    tndrBondExpiryWithoutAlertCounter++;

                                }
                                sqlCn.Close();
                            }

                            WriteToLog(DateTime.Now + "::" + "Successfully send the email notification to Tender Committee and updated the alert status for Expiration of Tender Bond Validity");
                            //}
                        }
                        catch (Exception ex)
                        {
                            WriteToLog(DateTime.Now + "::" + "Error occurred while sending the email notification to a member of Tender Committee" + "::" + ex.Message);
                        }
                    }
                }
            }
        }

        private PdfPTable createTable(DataTable dtTenderBondExpiry, PdfPTable pdfTab)
        {
                iTextSharp.text.Font plainText = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.TIMES_ROMAN, 8f);
                iTextSharp.text.Font boldText = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.TIMES_ROMAN, 9f, iTextSharp.text.Font.BOLD, iTextSharp.text.BaseColor.BLACK);                

                // storing header part in pdf file
                for (int i = 0; i < 7; i++)
                {
                    PdfPCell tabCell = new PdfPCell();
                    tabCell.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
                    tabCell.BorderWidth = 1f;
                    Paragraph snPg = null;

                    boldText.Color = new BaseColor(255, 255, 255);
                    if (i == 0)
                        snPg = new Paragraph("Date of Expiry", boldText);
                    if (i == 1)
                        snPg = new Paragraph("Tender No.", boldText);
                    if (i == 2)
                        snPg = new Paragraph("Project Title", boldText);
                    if (i == 3)
                        snPg = new Paragraph("Project Code", boldText);
                    if (i == 4)
                        snPg = new Paragraph("Committee", boldText);
                    if (i == 5)
                        snPg = new Paragraph("Tender Status", boldText);
                    if (i == 6)
                        snPg = new Paragraph("Department", boldText);

                    snPg.Alignment = iTextSharp.text.pdf.PdfContentByte.ALIGN_CENTER;
                    tabCell.BackgroundColor = new BaseColor(153, 0, 76);
                    tabCell.AddElement(snPg);
                    pdfTab.AddCell(tabCell);
                }
                pdfTab.HeaderRows = 1;

                // storing Each row and column value to pdf file
                for (int i = 0; i < dtTenderBondExpiry.Rows.Count; i++)
                {
                    for (int j = 0; j < 7; j++)
                    {
                        PdfPCell tabCell = new PdfPCell();
                        tabCell.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
                        Paragraph snPg = null;
                        snPg = new Paragraph(dtTenderBondExpiry.Rows[i][j].ToString(), plainText);
                        snPg.Alignment = iTextSharp.text.pdf.PdfContentByte.ALIGN_CENTER;
                        tabCell.AddElement(snPg);
                        pdfTab.AddCell(tabCell);
                    }

                }

                pdfTab.SpacingBefore = 10f;
                pdfTab.HorizontalAlignment = iTextSharp.text.pdf.PdfContentByte.ALIGN_CENTER;
                return pdfTab;
        }

        string strConn = ConfigurationManager.AppSettings["TCMSConnString"].ToString();       
        IList<string> userListColl = new List<string>();
        private void UserList_ForAlert(string sqlQuery)
        {
            userListColl.Clear();
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(strConn))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();                      

                        cmd.Connection = sqlConn;
                        cmd.CommandText = sqlQuery;
                        using (SqlDataReader dr = cmd.ExecuteReader())
                        {
                            while (dr.Read())
                            {
                                string strData = dr[0].ToString();
                                if (!userListColl.Contains(strData))
                                    userListColl.Add(strData);
                            }
                            dr.Close();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                WriteToLog(DateTime.Now + "::" + "Error occurred while creating Tender Bond Expiry table" + "::" + ex.Message);                                 
            }
        }

        public Boolean GetUserInformation4rmActiveDirectory(string userId, string Domain, ref string DisplayName, ref string Email, ref string Department, ref string Title)
        {
            Boolean chkUserExist = false;
            try
            {
                string filter = string.Format("(&(ObjectClass={0})(sAMAccountName={1}))", "person", userId);

                DirectoryEntry activeDirectoryaddress = new DirectoryEntry("LDAP://" + Domain, null, null, AuthenticationTypes.Secure);
                DirectorySearcher searcher = new DirectorySearcher(activeDirectoryaddress);
                searcher.SearchScope = SearchScope.Subtree;

                searcher.Filter = filter;
                SearchResult result = searcher.FindOne();
                DirectoryEntry directoryEntry = result.GetDirectoryEntry();

                DisplayName = directoryEntry.Properties["displayName"][0].ToString();
                Email = directoryEntry.Properties["mail"][0].ToString();
                Department = directoryEntry.Properties["department"][0].ToString();
                Title = directoryEntry.Properties["title"][0].ToString();

                if (Email != null)
                {
                    chkUserExist = true;
                }
            }
            catch (Exception ex)
            {                
                WriteToLog(DateTime.Now + "::" + "Sorry unable to get your mail id from outlook" + "::" + ex.Message);                
            }

            return chkUserExist;
        }
        protected override void OnStop()
        {
        }

        void WriteToLog(string errMsg)
        {
            FileStream fileStreamObj = null;
            StreamWriter streamWriterObj = null;
            string strFileName = ConfigurationManager.AppSettings["LogFile"];
            bool boolFlag = File.Exists(strFileName);

            if (boolFlag)
                fileStreamObj = new FileStream(strFileName, FileMode.Append, FileAccess.Write);
            else
                fileStreamObj = new FileStream(strFileName, FileMode.OpenOrCreate, FileAccess.Write);

            streamWriterObj = new StreamWriter(fileStreamObj);
            //if (lineCount != 1)
            //{
            //    streamWriterObj.WriteLine(errMsg.Split('.')[0]);
            //    streamWriterObj.WriteLine(errMsg.Split('.')[1]);
            //    streamWriterObj.WriteLine(streamWriterObj.NewLine);
            //    streamWriterObj.Flush();
            //}
            //else
            //{
            streamWriterObj.WriteLine(errMsg);
            streamWriterObj.WriteLine(streamWriterObj.NewLine);
            //streamWriterObj.Flush();
            //}
            streamWriterObj.Close(); 
            //fileStreamObj.Flush();
            fileStreamObj.Close();

        }

        public class PageEventHelper : PdfPageEventHelper
        {
            PdfTemplate template;
            protected BaseFont bf;

            public override void OnOpenDocument(PdfWriter writer, Document document)
            {
                template = writer.DirectContent.CreateTemplate(100, 100);
                template.BoundingBox = new iTextSharp.text.Rectangle(-20, -20, 100, 100);
                bf = BaseFont.CreateFont(BaseFont.TIMES_ROMAN, BaseFont.CP1252, BaseFont.NOT_EMBEDDED);
            }

            public override void OnEndPage(PdfWriter writer, Document document)
            {
                //base.OnEndPage(writer, document);
                PdfContentByte cb = writer.DirectContent;

                int pageN = writer.PageNumber;
                String text = "Page " + pageN + " of ";
                float len = bf.GetWidthPoint(text, 9);

                iTextSharp.text.Rectangle pageSize = document.PageSize;

                //cb.SetRGBColorFill(100, 100, 100);

                cb.BeginText();
                cb.SetFontAndSize(bf, 9);
                cb.SetTextMatrix(pageSize.GetLeft(70), pageSize.GetBottom(30));
                cb.ShowText(System.DateTime.Now.ToLongDateString());
                cb.EndText();

                //cb.AddTemplate(template, pageSize.GetLeft(70) + len, pageSize.GetBottom(30));

                //cb.BeginText();
                //cb.SetFontAndSize(bf, 9);
                //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT,
                //    "",
                //    pageSize.GetLeft(70),
                //    pageSize.GetBottom(30), 0);
                //cb.EndText();

                cb.BeginText();
                cb.SetFontAndSize(bf, 9);
                cb.SetTextMatrix(pageSize.GetRight(70), pageSize.GetBottom(30));
                cb.ShowText(text);
                cb.EndText();

                cb.AddTemplate(template, pageSize.GetRight(70) + len, pageSize.GetBottom(30));

                //cb.BeginText();
                //cb.SetFontAndSize(bf, 9);
                //cb.ShowTextAligned(PdfContentByte.ALIGN_RIGHT,
                //    "",
                //    pageSize.GetRight(70),
                //    pageSize.GetBottom(30), 0);
                //cb.EndText();
            }

            public override void OnCloseDocument(PdfWriter writer, Document document)
            {
                //base.OnCloseDocument(writer, document);

                template.BeginText();
                template.SetFontAndSize(bf, 9);
                template.SetTextMatrix(0, 0);
                template.ShowText("" + (writer.PageNumber - 1));
                template.EndText();
            }

        }
    }
}
